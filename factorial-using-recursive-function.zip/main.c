/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int factorial(int val){
    int mul=1,result;
    if(val==1){
        return 1;
    }
    else{
        result=mul*val;
        return result*factorial(val-1);
    }
}

int main()
{
    int val;
    scanf("%d",&val);
    int b= factorial(val);
    printf("The factorial is:%d",b);
    return 0;
}
